import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FirebaseService } from '../firebase.service';
import { UserCredential } from 'firebase/auth';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css'],
  standalone: true,
  imports: [CommonModule, FormsModule],
})
export class LoginPageComponent {
  username: string = '';
  password: string = '';
  errorMessage: string = '';

  constructor(private firebaseService: FirebaseService) {}

  onLogin() {
    this.firebaseService
      .login(this.username, this.password)
      .then((userCredential: UserCredential) => {
        console.log('Login successful:', userCredential);
        alert('Login successful!');
      })
      .catch((error: Error) => {
        console.error('Login error:', error);
        this.errorMessage = error.message;
      });
  }
}
