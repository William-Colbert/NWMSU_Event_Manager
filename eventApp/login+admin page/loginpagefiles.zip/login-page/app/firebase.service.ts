import { initializeApp } from 'firebase/app';
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, Auth } from 'firebase/auth';
import { Injectable } from '@angular/core';

const firebaseConfig = {
    apiKey: "AIzaSyDfA1u8dD8UnBStomM5vRNupK4H456IW48",
    authDomain: "nwmsu-event-manager.firebaseapp.com",
    projectId: "nwmsu-event-manager",
    storageBucket: "nwmsu-event-manager.firebasestorage.app",
    messagingSenderId: "933816110403",
    appId: "1:933816110403:web:5b2cc4a9a3259f94dc73f6",
    measurementId: "G-ZVF490QDTD"
};

const firebaseApp = initializeApp(firebaseConfig);
const auth = getAuth(firebaseApp);

@Injectable({
  providedIn: 'root',
})
export class FirebaseService {
  constructor() {}

  // Login method
  login(email: string, password: string) {
    return signInWithEmailAndPassword(auth, email, password);
  }

  // Sign-up method
  signUp(email: string, password: string) {
    return createUserWithEmailAndPassword(auth, email, password);
  }
}
