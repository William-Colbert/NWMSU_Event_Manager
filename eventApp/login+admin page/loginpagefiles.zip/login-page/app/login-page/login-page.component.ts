import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FirebaseService } from '../firebase.service';
import { UserCredential } from 'firebase/auth';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css'],
  standalone: true,
  imports: [CommonModule, FormsModule],
})
export class LoginPageComponent {
  email: string = '';
  password: string = '';
  errorMessage: string = '';
  isSignUp: boolean = false; // Track if the user is signing up

  constructor(
    private firebaseService: FirebaseService,
    private router: Router
  ) {}

  onLogin(event: Event) {
    event.preventDefault(); // Prevent the default form submission behavior
  
    if (this.isSignUp) {
      this.firebaseService
        .signUp(this.email, this.password)
        .then((userCredential: UserCredential) => {
          console.log('Sign-up successful:', userCredential);
          alert('Sign-up successful!');
          window.location.reload(); // Reload the page after sign-up
        })
        .catch((error: Error) => {
          console.error('Sign-up error:', error);

          // Check for specific Firebase error codes
          if (error.message.includes('email-already-in-use')) {
            this.errorMessage = 'This email is already in use. Please use a different email or log in.';
          } else {
            this.errorMessage = 'An error occurred during sign-up. Please try again.';
          }
        });
    } else {
      this.firebaseService
        .login(this.email, this.password)
        .then((userCredential: UserCredential) => {
          console.log('Login successful:', userCredential);
          alert('Login successful!');
          this.router.navigate(['/admin']); // Navigate to admin page after successful login
        })
        .catch((error: Error) => {
          console.error('Login error:', error);
          this.errorMessage = 'Incorrect email or password. Please try again.'; // Display login error message
        });
    }
  }

  toggleSignUp() {
    this.isSignUp = !this.isSignUp; // Toggle between login and sign-up mode
    this.errorMessage = ''; // Clear error message when toggling
  }
}